/**
 * Created by Wang Chong on 2016/03/31.
 */
(function ($) {
    var Guagua = function (selector, params) {
        return new Guagua.prototype.init(selector, params);
    };

    Guagua.prototype.init = function (selector, params) {
        var canvas = {},
            that = this,
            $item = this.dom = $(selector),
            ctx = {},
            system = isPc() ? 'PC' : 'NOT_PC',
            isImage = this.isImage = $item.is('img'),
            debuggerMode = (params.mode === 'debugger'),
            radius = params.radius = params.radius || 20,
            maxSize = params.maxSize || 0.3,
            width = params.width = params.width || ($item.length && $item.width()) || '400',
            height = params.height = params.height || ($item.length && $item.height()) || '380',
            fillColor = params.color = params.color || '#c0c0c0',
            scratchStartFn = params.start || function () {},
            scratchEndFn = params.end || function () {},
            scratchingFn = params.scratching || function(){},
            ready = params.ready || function () {},
            completeFn = params.complete || function () {};

        this.isDisTouching = false;
        this.params =  params || {};
        //如果选择器为空
        if (!$item.length) {
            return
        }
        //禁止拖动设置
        $item[0].ontouchmove = function (e) {
            e.preventDefault();
        };
        $item[0].startDrag = function (e) {
            e.preventDefault();
        };

        //判断浏览器是否支持canvas
        try {
            document.createElement('canvas').getContext('2d');
        } catch (e) {
            return [];
        }

        //-->>创建canvas
        canvas = that.canvas = createCanvas($item, isImage, params);
        that.id = canvas.node.id;
        //-->>创建grids
        that.grid = createGrid(width, height, radius);
        ctx = canvas.context;
        //if(isImage){
        //    $item.remove();
        //    ctx.drawImage($item[0], 0, 0, width, height);
        //}


        //-->>为canvas自定义方法
        //描绘当前手指刮触区域
        ctx.fillTouchArea = function (x, y, radius) {
            this.beginPath();
            this.moveTo(x, y);
            this.arc(x, y, radius, 0, Math.PI * 2, false);
            this.fill();
        };

        //重绘可刮区域
        ctx.reset = function (fillColor, isImage, scope) {
            var $item = scope.dom;
            ctx.globalCompositeOperation = "source-over";
            if (!isImage) {
                ctx.fillStyle = fillColor;
                ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
            } else {
                $item.remove();
                ctx.drawImage($item[0], 0, 0, this.canvas.width, this.canvas.height);
            }
            scope.params.bgImg && (this.canvas.style.backgroundImage = 'url(' + scope.params.bgImg + ')');

            this.canvas.style.backgroundSize = '100% 100%';
        };

        //立即重绘可刮区域
        ctx.reset(fillColor, isImage, this);
        ready();

        //-->>为canvas绑定事件
        //添加touchStart事件
        canvas.node.addEventListener(system === "PC" ? "mousedown" : "touchstart", function (e) {
            canvas.isDrawing = true;
            scratchStartFn(e);
            e.preventDefault();
        }, false);

        //添加touchEnd事件
        canvas.node.addEventListener(system === "PC" ? "mouseup" : "touchend", function (e) {
            canvas.isDrawing = false;
            debuggerMode && console.log(getGridsPercent(that.grid) * 100);
            if (getGridsPercent(that.grid) > maxSize) {
                completeFn();
            }
            scratchEndFn(e);
            that.isDisTouching = false;
            e.preventDefault();
        }, false);

        //添加touchMove事件
        canvas.node.addEventListener(system === "PC" ? "mousemove" : "touchmove", function (e) {
            var x,y;
            if (!canvas.isDrawing) {
                return;
            }
            if(!that.isDisTouching){
                //调用滑动函数
                scratchingFn();
                that.isDisTouching = true;
            }

            var rect = this.getBoundingClientRect();
            if (system !== 'PC') {
                x = e.changedTouches[0].pageX - rect.left;
                y = e.changedTouches[0].pageY - rect.top;
            } else {
                x = e.pageX - rect.left;
                y = e.pageY - rect.top;
            }

            setGrids(that.grid, x, y, radius);
            e.preventDefault();
            ctx.globalCompositeOperation = 'destination-out';
            ctx.fillTouchArea(x, y, radius);
        }, false);


        //设置返回值
        for (var i = 0, len = $item.length; i < len; i++) {
            this[i] = $item[i];
        }
        this.length = $item.length;
        return this;
    };

    /**
     * 检查客户端是否为PC
     * @returns {boolean}
     * @constructor
     */
    function isPc()
    {
        var userAgentInfo = navigator.userAgent,
            Agents = ["Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod"],
            flag = true;
        for (var v = 0; v < Agents.length; v++) {
            if (userAgentInfo.indexOf(Agents[v]) > 0) { flag = false; break; }
        }
        return flag;
    }
    /**
     * 创建Canvas
     * @param parent
     * @param isImage 是否为图片
     * @param params 参数集合
     * @returns {{}}
     */
    function createCanvas(parent, isImage, params) {
        var canvas = {},
            width = params.width || '100%',
            height = params.height || '100%';
        canvas.node = document.createElement('canvas');
        canvas.context = canvas.node.getContext('2d');
        canvas.node.id = 'guaguaCanvas_' + (new Date()).getTime();

        //此处可以自己给标签添加
        canvas.node.width = width;
        canvas.node.height = height;
        //给canvas标签添加Id
        if (isImage) {
            parent.after(canvas.node)
        } else {
            parent[0].appendChild(canvas.node);
        }

        return canvas;
    }

    function createGrid(canvasWidth, canvasHeight, radius) {
        var x = Math.round(canvasWidth / (radius * 2)),
            y = Math.round(canvasHeight / (radius * 2)),
            grid = [];
        for (var i = 0; i < x; i++) {
            grid.push(new Array(y))
        }
        return grid;
    }

    /**
     * 设置矩阵中的点（x:代表横轴；y:代表纵轴）
     * @param grid ：矩阵（二维数组）
     * @param x ：横坐标
     * @param y ：纵坐标
     * @param radius :半径
     */
    function setGrids(grid, x, y, radius) {
        var gridWidth = grid.length,
            gridHeight = grid[0].length,
            rX = x < radius * 2 ? 0 : Math.round(x / (radius * 2)) - 1,
            rY = y < radius * 2 ? 0 : Math.round(y / (radius * 2)) - 1;
        try {
            if (rX < gridWidth && rY < gridHeight) {
                grid[rX][rY] = true;
            }
        } catch (e) {
            console.error(rX, gridWidth, rY, gridHeight)
        }
    }

    function getGridsPercent(grid) {
        var counter = 0,
            gridsNum = grid.length * grid[0].length;
        for (var i = 0, lenI = grid.length; i < lenI; i++) {
            for (var j = 0, lenJ = grid[i].length; j < lenJ; j++) {
                grid[i][j] && counter++
            }
        }
        return counter / gridsNum;
    }


    Guagua.prototype.clear = function () {
        var that = this,
            callback = callback || function(){};
        that.canvas.context.clearRect(0,0,that.params.width,that.params.height);
        for(var i=0, lenI = that.grid.length; i < lenI; i++){
            for(var j= 0, lenJ= that.grid[i].length; j <lenJ; j++)that.grid[i][j] = true;
        }
        callback();
        that.cardScratched = false;
    };

    Guagua.prototype.reset = function () {
        var that = this,
            ctx = that.canvas.context,
            callback = callback || function(){};
        ctx.reset(that.params.color, that.isImage, that);
        that.grid = createGrid(that.params.width,that.params.height, that.params.radius);
        that.cardScratched = false;
        callback();
    };

    Guagua.prototype.init.prototype = Guagua.prototype;
    window.Scratch = Guagua;
})($);
