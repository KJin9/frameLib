var gulp = require('gulp'),
    rename = require('gulp-rename'),
    uglify = require('gulp-uglify');

gulp.task('jsMinify', function() {
    //JS minify
    return gulp.src(['./scratch.js'])
        .pipe(uglify())
        .pipe(rename('scratch.min.js'))
        .pipe(gulp.dest('./'));
});

gulp.task('default',['jsMinify']);