
##ScratchJS是什么?

一款实现刮刮卡效果的JS组件，它是基于jQuery和HTML5的canvas开发而成。

##ScratchJS有哪些功能？

* 带有前景图片的刮刮卡效果
* 仅有图层的刮刮卡效果

##Hello World

* 这里以带有前景图片的效果为例，当然你也可以在demo文件夹中找到使用例子

 * picture.html：带有前景图片的效果例子

 * fillColor.html：只有图层颜色的效果例子

* HTML代码
```html
  <div>
      <img style="width: 40%;min-width: 400px" id="frontImg" src="./xxxFront.jpg">
  </div>
```
* JavaScript代码
```javascript
    var scratch = Scratch('img', {
        bgImg: './xxxBack.jpg',    //背景图片
        radius: 20,    //手指刮开区域的半径（单位px）
        maxSize: 0.5,   //最大刮开半分比，当达到此百分比时，即调用complete回调
        complete: function(){
            scratch.clear();  //当刮开百分比大于50%时，将自动全部刮开
        }
    });
```

##有问题反馈
在使用中有任何问题，欢迎反馈给我，可以用以下联系方式跟我交流

* 邮件：(royneedyou@aliyun.com)
* 微博：[@无敌王冲](http://weibo.com/royhappy)

