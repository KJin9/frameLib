/** @language chinese
 * <p>lufylegend专用MVC框架。</p>
 * <p><a href="../../mvc/index.html">点击这里看lufylegend.mvc文档</a>。</p>
 * @class lufylegend.mvc
 * @since 1.8.4
 * @public
 */