function ArmsConfig(){
}
ArmsConfig.Arms = [{id:1},{id:2},{id:3},{id:4},{id:5},{id:6}];
//步兵
ArmsConfig.INFANTRY = 0;
//骑兵
ArmsConfig.CAVALRY = 1;

//刀兵
ArmsConfig.KNIFE = 0;
//斧兵
ArmsConfig.AXEMAN = 1;
//弓兵
ArmsConfig.ARCHER = 2;

ArmsConfig.MAX_ID = 50;