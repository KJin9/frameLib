function BattleMapConfig(){
}
BattleMapConfig.GameClear = "gameClear";
BattleMapConfig.GameOver = "gameOver";
BattleMapConfig.GameNext = "gameNext";
BattleMapConfig.GameBattle = "gameBattle";
BattleMapConfig.SPEED = 5;
BattleMapConfig.STEP_WIDTH = 320;
BattleMapConfig.STEP_HEIGHT = 240;
BattleMapConfig.DATA_NULL = 0;
BattleMapConfig.DATA_OUR_CHARACTER = 1;
BattleMapConfig.DATA_ENEMY_CHARACTER = 2;
BattleMapConfig.DATA_OUR_CASTLE = 3;
BattleMapConfig.DATA_ENEMY_CASTLE = 4;