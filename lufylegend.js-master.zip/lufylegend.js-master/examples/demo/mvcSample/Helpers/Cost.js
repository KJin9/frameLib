function GetMaxCost(level) {
	return 100 + level * 5;
}