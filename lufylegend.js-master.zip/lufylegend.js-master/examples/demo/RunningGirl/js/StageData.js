var StageData = {
	getFloor:function(index){
		var floor;
		floor = new Floor(index);
		return floor;
	}
};
